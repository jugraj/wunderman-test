# Wunderman Tech Test

## Installation

```
npm i
```

## Compile and run

```
npm start
```

## To build

```
npm run build
```

## Author

Jay Sukhija
jugraj@gmail.com

### Notes:

App uses `axios` to fetch the FAQs data and iterates through using map in the render function. All stying is placed in `style.scss` and logic in `App.jsx`.
